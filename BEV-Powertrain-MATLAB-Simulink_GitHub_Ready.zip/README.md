# Battery Electric Vehicle Powertrain Modelling — MATLAB/Simulink

Academic project exploring an electric vehicle powertrain and its component-level modelling using MATLAB/Simulink.

## Overview

The original project provides two Simulink models and an associated electric-powertrain assignment that discusses permanent-magnet synchronous motors (PMSMs), traction inverters, gear ratios, battery state-of-charge (SOC), and the FTP-75 driving cycle.

## Models

| Model | Source filename | Purpose |
| --- | --- | --- |
| BEV components | `models/BEV_Components_OctNov24.slx` | Original component-level Simulink model |
| BEV mileage | `models/BEV_Milg_OctNov24.slx` | Original BEV simulation model |

The models are provided in their original `.slx` format. Their internal dependencies, MATLAB toolboxes, and results have not been independently validated here.

## Reported study results

In the source assignment, an FTP-75 example reports a cycle duration of 2,475 seconds, approximately 2.5 kWh consumed during one cycle, a 53 kWh battery, a final SOC around 95.1%, and 17.77 km travelled (approximately 0.14 kWh/km). **These are assignment-reported values, not independently reproduced measurements.** Other configurations and calculations appear in the assignment; these values represent only one discussed scenario.

## Open and explore

1. Install MATLAB and Simulink plus any toolboxes required by the models.
2. Open `models/BEV_Components_OctNov24.slx` to explore the component model.
3. Open `models/BEV_Milg_OctNov24.slx` to explore the driving model.
4. Review model parameters and block dependencies before running a simulation.
5. Collect plots (vehicle speed, motor performance, SOC, power/energy) for presentation if the models run in your environment.

## Portfolio highlights

- Electric vehicle powertrain and component modelling
- Permanent-magnet synchronous motor and inverter principles
- Battery SOC and energy-consumption analysis
- Driving-cycle evaluation in MATLAB/Simulink

## Limitations

- This repository preserves two supplied project models; the original assignment is omitted because it contains personal student information.
- No claim is made that the models compile/run on a particular MATLAB release.
- Reported figures have not been reproduced or independently verified.
- Educational simulation only; not a validated production EV controller.

## License

No license is granted for reuse of the model files until the author selects one and verifies all third-party blocks and materials are redistributable.
