# Suggested 6-slide presentation

1. **Objective:** BEV powertrain performance and energy consumption through MATLAB/Simulink.
2. **Architecture:** Battery → inverter → PMSM → transmission → vehicle dynamics (confirm exact connections in model).
3. **Simulink project:** Show screenshots of the `BEV_Components` and `BEV_Milg` models.
4. **Driving cycle:** Describe the FTP-75 study and stated 2,475-second cycle duration.
5. **Results from source assignment:** A discussed example reports 2.5 kWh per cycle, 53 kWh battery, 95.1% final SOC, and 17.77 km; note these have not been independently rerun.
6. **Learning and next steps:** Validate model dependencies, reproduce plots, compare drive cycles, sensitivity to gear ratio and motor sizing.

Avoid presenting assignment-derived figures as independently measured or verified results.
